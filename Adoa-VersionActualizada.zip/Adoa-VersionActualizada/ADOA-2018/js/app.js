$(document).ready(function(){

	// $('.modal').modal();
	    $('.sidenav').sidenav();
        $('.tabs').tabs();
        $('select').formSelect();
        $('.input-field label').addClass('active');



});